#! /bin/bash
java -Djava.library.path=. -jar Java3Dthing.jar
